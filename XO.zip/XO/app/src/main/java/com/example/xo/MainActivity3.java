package com.example.xo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity3 extends AppCompatActivity {
        EditText text;
        Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        text = (EditText) findViewById(R.id.da);
        button = (Button) findViewById(R.id.BackToGame);

        Intent intent = getIntent();
        String Pobeda = intent.getStringExtra("Pobeda");

        text.setText(Pobeda);

            button.setOnClickListener(view -> {
                Intent intent1 = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(intent1);
                });
    }
}