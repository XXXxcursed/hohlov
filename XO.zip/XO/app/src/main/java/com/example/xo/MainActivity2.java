package com.example.xo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {
    Button bt1;Button bt2;Button bt3;Button bt4;Button bt5;Button bt6;Button bt7;Button bt8;
    Button bt9;
    EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        bt1 = findViewById(R.id.button);
        bt2 = findViewById(R.id.button1);
        bt3 = findViewById(R.id.button2);
        bt4 = findViewById(R.id.button3);
        bt5 = findViewById(R.id.button4);
        bt6 = findViewById(R.id.button5);
        bt7 = findViewById(R.id.button6);
        bt8 = findViewById(R.id.button7);
        bt9 = findViewById(R.id.button8);
        text = findViewById(R.id.Pobeda);
    }
    public boolean XO;
    public int proverka = 0;


    public void logic(View v)
    {
        switch (v.getId())
        {
            case R.id.button:
                if(XO) {
                    bt1.setText("0");
                    XO = false;
                }
                else {
                    bt1.setText("X");
                    XO = true;
                }
                bt1.setEnabled(false);
                proverka++;
                break;
            case R.id.button1:
                if(XO) {
                    bt2.setText("0");
                    XO = false;
                }
                else {
                    bt2.setText("X");
                    XO = true;
                }
                proverka++;
                bt2.setEnabled(false);
                break;
            case R.id.button2:
                if(XO) {
                    bt3.setText("0");
                    XO = false;
                }
                else {
                    bt3.setText("X");
                    XO = true;
                }
                proverka++;
                bt3.setEnabled(false);
                break;
            case R.id.button3:
                if(XO) {
                    bt4.setText("0");
                    XO = false;
                }
                else {
                    bt4.setText("X");
                    XO = true;
                }
                proverka++;
                bt4.setEnabled(false);
                break;
            case R.id.button4:
                if(XO) {
                    bt5.setText("0");
                    XO = false;
                }
                else {
                    bt5.setText("X");
                    XO = true;
                }
                proverka++;
                bt5.setEnabled(false);
                break;
            case R.id.button5:
                if(XO) {
                    bt6.setText("0");
                    XO = false;
                }
                else {
                    bt6.setText("X");
                    XO = true;
                }
                proverka++;
                bt6.setEnabled(false);
                break;
            case R.id.button6:
                if(XO) {
                    bt7.setText("0");
                    XO = false;
                }
                else {
                    bt7.setText("X");
                    XO = true;
                }
                proverka++;
                bt7.setEnabled(false);
                break;
            case R.id.button7:
                if(XO) {
                    bt8.setText("0");
                    XO = false;
                }
                else {
                    bt8.setText("X");
                    XO = true;
                }
                proverka++;
                bt8.setEnabled(false);
                break;
            case R.id.button8:
                if(XO) {
                    bt9.setText("0");
                    XO = false;
                }
                else {
                    bt9.setText("X");
                    XO = true;
                }
                proverka++;
                bt9.setEnabled(false);
                break;
        }
        if (!bt1.getText().toString().isEmpty() && !bt3.getText().toString().isEmpty()) {
            if (bt1.getText() == bt2.getText() && bt1.getText() == bt3.getText()) {
                text.setText("Есть победитель");
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("Pobeda",text.getText().toString());
                startActivity(intent);
                proverka--;
            }
        }
        if (!bt1.getText().toString().isEmpty() && !bt9.getText().toString().isEmpty()) {
        if (bt1.getText() == bt5.getText() && bt1.getText() == bt9.getText()) {
            text.setText("Есть победитель");
            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
            intent.putExtra("Pobeda",text.getText().toString());
            startActivity(intent);
                proverka--;
            }

        }
        if (!bt1.getText().toString().isEmpty() && !bt7.getText().toString().isEmpty()) {
            if (bt1.getText() == bt4.getText() && bt1.getText() == bt7.getText()) {
                text.setText("Есть победитель");
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("Pobeda",text.getText().toString());
                startActivity(intent);
                proverka--;
            }

        }
        if (!bt2.getText().toString().isEmpty() && !bt8.getText().toString().isEmpty()) {
            if (bt2.getText() == bt5.getText() && bt2.getText() == bt8.getText()) {
                text.setText("Есть победитель");
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("Pobeda",text.getText().toString());
                startActivity(intent);
                proverka--;
            }

        }
        if (!bt3.getText().toString().isEmpty() && !bt6.getText().toString().isEmpty()) {
            if (bt3.getText() == bt6.getText() && bt3.getText() == bt9.getText()) {
                text.setText("Есть победитель");
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("Pobeda",text.getText().toString());
                startActivity(intent);
                proverka--;
            }

        }
        if (!bt3.getText().toString().isEmpty() && !bt7.getText().toString().isEmpty()) {
            if (bt3.getText() == bt5.getText() && bt3.getText() == bt7.getText()) {
                text.setText("Есть победитель");
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("Pobeda",text.getText().toString());
                startActivity(intent);
                proverka--;
            }

        }
        if (!bt4.getText().toString().isEmpty() && !bt6.getText().toString().isEmpty()) {
            if (bt4.getText() == bt5.getText() && bt4.getText() == bt6.getText()) {
                text.setText("Есть победитель");
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("Pobeda",text.getText().toString());
                startActivity(intent);
                proverka--;
            }

        }
        if (!bt7.getText().toString().isEmpty() && !bt9.getText().toString().isEmpty()) {
            if (bt7.getText() == bt8.getText() && bt7.getText() == bt9.getText()) {
              //  AlertDialog.Builder dialog = new AlertDialog.Builder(this);
              //  dialog.setMessage("есть победитель!");
              //  dialog.create().show();
                text.setText("Есть победитель");
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("Pobeda",text.getText().toString());
                startActivity(intent);
                proverka--;
            }

        }
        if (proverka == 9)
        {
            text.setText("Ничья");
            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
            intent.putExtra("Pobeda",text.getText().toString());
            startActivity(intent);
        }

    }
}